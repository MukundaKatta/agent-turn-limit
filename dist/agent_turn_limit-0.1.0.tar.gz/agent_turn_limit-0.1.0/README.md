# agent-turn-limit

Hard turn cap and threshold warnings for LLM agent loops.

Zero dependencies. Python 3.10+. MIT.

## The problem

Agent loops run until a stop condition. Stop conditions sometimes fail — the model loops
back, tool calls chain, the exit check is off by one. Without a hard upper bound, an
agent can run 500 turns and rack up a $40 API bill before anyone notices.

`agent-turn-limit` adds a hard cap. You also get configurable warning thresholds so you
know when an agent is "getting long" before it blows the limit.

## Install

```bash
pip install agent-turn-limit
```

## Basic usage

```python
from agent_turn_limit import make_turn_counter, TurnLimitExceeded

counter = make_turn_counter(hard_limit=20)

while True:
    counter.tick()   # raises TurnLimitExceeded at turn 21
    response = client.messages.create(...)
    if is_done(response):
        break
```

Default warning thresholds: 50% and 80% of `hard_limit`.

## Warnings

```python
import logging
from agent_turn_limit import make_turn_counter, TurnWarning

def log_warning(w: TurnWarning) -> None:
    logging.warning(w.message)
    # "agent: turn 10/20 (10 remaining)"

counter = make_turn_counter(
    hard_limit=20,
    warn_at=[10, 16],   # integer turn numbers
    on_warn=log_warning,
)
```

Or use fractions of the hard limit:

```python
counter = make_turn_counter(
    hard_limit=20,
    warn_at=[0.5, 0.8],  # turns 10 and 16
    on_warn=log_warning,
)
```

## stop_on_limit=False

If you want to handle the limit yourself instead of catching an exception:

```python
from agent_turn_limit import TurnCounter

counter = TurnCounter(hard_limit=20, stop_on_limit=False)

while True:
    if not counter.tick():
        print(f"Stopped after {counter.turn} turns")
        break
    ...
```

## Context manager

```python
from agent_turn_limit import TurnCounter, TurnLimitExceeded

try:
    with TurnCounter(hard_limit=10, label="summarizer") as c:
        while True:
            c.tick()
            ...
except TurnLimitExceeded as e:
    print(e)  # "summarizer: hard turn limit of 10 exceeded (turn 11)"
```

## API

### `make_turn_counter(hard_limit, *, warn_at=None, on_warn=None, stop_on_limit=True, label="agent") -> TurnCounter`

Factory with sensible defaults (`warn_at=[0.5, 0.8]`).

### `TurnCounter`

```python
@dataclass
class TurnCounter:
    hard_limit: int
    warn_at: list[int | float]
    on_warn: Callable[[TurnWarning], None] | None
    stop_on_limit: bool
    label: str

    @property
    def turn(self) -> int: ...         # current turn number
    @property
    def remaining(self) -> int: ...    # turns left before hard limit
    @property
    def is_exhausted(self) -> bool: ...

    def tick(self) -> bool: ...        # advance; raises or returns False at limit
    def reset(self) -> None: ...       # reset to turn 0
```

### `TurnWarning`

```python
@dataclass
class TurnWarning:
    turn: int
    hard_limit: int
    remaining: int
    message: str
```

### `TurnLimitExceeded`

Subclass of `TurnLimitError`. Raised by `tick()` when `stop_on_limit=True` and the
hard limit is exceeded.

## License

MIT
